SET SQL_SAFE_UPDATES = 0;
delete from participatesin;
delete from interview;
delete from recruiter;
delete from worksin;
delete from socialuser;
delete from jobpost;
delete from branchesinto;
delete from jobposition;

delete from company;

DROP INDEX JobPostDescription on JobPost;
